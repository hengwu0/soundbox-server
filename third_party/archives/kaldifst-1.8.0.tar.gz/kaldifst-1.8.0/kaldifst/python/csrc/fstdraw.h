// kaldifst/python/csrc/fstdraw.h
//
// Copyright (c)  2021  Xiaomi Corporation (authors: Fangjun Kuang)

#ifndef KALDIFST_PYTHON_CSRC_FSTDRAW_H_
#define KALDIFST_PYTHON_CSRC_FSTDRAW_H_

#include <memory>
#include <string>

#include "fst/script/draw.h"
#include "kaldifst/csrc/lattice-weight.h"
#include "kaldifst/python/csrc/kaldifst.h"

namespace kaldifst {

static std::unique_ptr<const fst::SymbolTable> GetDrawSymbolTable(
    const py::object &obj, bool allow_negative_labels) {
  using fst::SymbolTable;

  std::unique_ptr<const SymbolTable> syms;
  if (obj.is_none()) return syms;

  if (py::isinstance<py::str>(obj)) {
    syms.reset(SymbolTable::ReadText(py::cast<std::string>(obj)));
  } else {
    syms.reset(py::cast<SymbolTable *>(obj)->Copy());
  }

  KALDIFST_ASSERT(syms);
  if (!allow_negative_labels) {
    for (const auto &item : *syms) {
      if (item.Label() < 0) {
        KALDIFST_ERR << "Negative labels are not allowed in symbol tables";
      }
    }
  }
  return syms;
}

void PybindFstDraw(py::module &m);  // NOLINT

struct FstDrawParams {
  // Input in acceptor format
  bool acceptor = false;

  // Input label symbol table
  py::object isymbols;

  // Output label symbol table
  py::object osymbols;

  // State label symbol table
  py::object ssymbols;

  // Print numeric labels
  bool numeric = false;

  // Set precision (number of char/float)
  int32_t precision = 5;

  // Floating-point format, one of: "e", "f", or "g"
  std::string float_format = "g";
  // Print/draw arc weights and final weights equal to Weight::One()
  bool show_weight_one = false;

  // Set figure title
  std::string title = "";

  // Portrait mode (def: landscape)
  bool portrait = false;

  // Draw bottom-to-top instead of left-to-right
  bool vertical = false;

  // Set fontsize
  int32_t fontsize = 14;

  // Set height
  double height = 11;

  // Set width
  double width = 8.5;

  // Set minimum separation between nodes (see dot documentation)
  double nodesep = 0.25;

  // Set minimum separation between ranks (see dot documentation)
  double ranksep = 0.40;

  // Allow negative labels (not recommended; may cause conflicts)
  bool allow_negative_labels = false;
};

template <typename A>
std::string FstDrawImpl(const fst::script::FstClass &fst,
                        const FstDrawParams &params) {
  std::ostringstream os;

  auto isyms = GetDrawSymbolTable(params.isymbols, params.allow_negative_labels);
  auto osyms = GetDrawSymbolTable(params.osymbols, params.allow_negative_labels);
  auto ssyms = GetDrawSymbolTable(params.ssymbols, params.allow_negative_labels);

  if (!isyms && !params.numeric && fst.InputSymbols()) {
    isyms.reset(fst.InputSymbols()->Copy());
  }

  if (!osyms && !params.numeric && fst.OutputSymbols()) {
    osyms.reset(fst.OutputSymbols()->Copy());
  }

  std::string dest = "";
  fst::FstDrawer<A> a(
      *fst.GetFst<A>(), isyms.get(), osyms.get(), ssyms.get(), params.acceptor,
      params.title, params.width, params.height, params.portrait,
      params.vertical, params.ranksep, params.nodesep, params.fontsize,
      params.precision, params.float_format, params.show_weight_one, "dot");
  a.Draw(os, dest);
  return os.str();
}

template <typename A>
void PybindFstDraw(py::module &m,  // NOLINT
                   const char *doc = "") {
  using PyClass = fst::Fst<A>;

  m.def(
      "draw",
      [](const PyClass &fst, bool acceptor = false,
         py::object isymbols = py::none(), py::object osymbols = py::none(),
         py::object ssymbols = py::none(), bool numeric = false,
         int32_t precision = 5, const std::string &float_format = "g",
         bool show_weight_one = false, const std::string &title = "",
         bool portrait = false, bool vertical = false, int32_t fontsize = 14,
         double height = 11, double width = 8.5, double nodesep = 0.25,
         double ranksep = 0.40,
         bool allow_negative_labels = false) -> std::string {
        auto _fst = fst::script::FstClass(fst);
        FstDrawParams params;
        params.acceptor = acceptor;
        params.isymbols = isymbols;
        params.osymbols = osymbols;
        params.ssymbols = ssymbols;
        params.numeric = numeric;
        params.precision = precision;
        params.float_format = float_format;
        params.show_weight_one = show_weight_one;
        params.title = title;
        params.portrait = portrait;
        params.vertical = vertical;
        params.fontsize = fontsize;
        params.height = height;
        params.width = width;
        params.nodesep = nodesep;
        params.ranksep = ranksep;
        params.allow_negative_labels = allow_negative_labels;
        return FstDrawImpl<A>(_fst, params);
      },
      py::arg("fst"), py::arg("acceptor") = false,
      py::arg("isymbols") = py::none(), py::arg("osymbols") = py::none(),
      py::arg("ssymbols") = py::none(), py::arg("numeric") = false,
      py::arg("precision") = 5, py::arg("float_format") = "g",
      py::arg("show_weight_one") = false, py::arg("title") = "",
      py::arg("portrait") = false, py::arg("vertical") = false,
      py::arg("fontsize") = 14, py::arg("height") = 11, py::arg("width") = 8.5,
      py::arg("nodesep") = 0.25, py::arg("ranksep") = 0.40,
      py::arg("allow_negative_labels") = false, doc);
}

}  // namespace kaldifst

#endif  // KALDIFST_PYTHON_CSRC_FSTDRAW_H_
